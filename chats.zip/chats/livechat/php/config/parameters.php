<?php

return array (
  'dbHost' => '127.0.0.1',
  'dbPort' => '3306',
  'dbUser' => 'root',
  'dbPassword' => 'root',
  'dbName' => 'chat_lite',
  'superUser' => 'admin',
  'superPass' => 'admin123',
  'appSettings' => 
  array (
    'contactMail' => 'admin@domain.com',
  ),
);

?>